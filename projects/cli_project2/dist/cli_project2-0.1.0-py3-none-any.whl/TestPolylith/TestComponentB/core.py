def testFunctionA():
    return "TestComponentB.testFunctionA"
