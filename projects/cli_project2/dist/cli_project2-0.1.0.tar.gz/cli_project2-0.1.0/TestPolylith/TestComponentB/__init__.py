from TestPolylith.TestComponentB import core

__all__ = ["core"]
