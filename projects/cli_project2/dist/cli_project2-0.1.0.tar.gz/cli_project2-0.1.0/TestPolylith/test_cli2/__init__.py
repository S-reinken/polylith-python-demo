from TestPolylith.test_cli2 import core

__all__ = ["core"]
