def testFunctionA():
    return "TestComponentA.testFunctionA"
